% % % Copyright (c) 2012, Ingo B�rk
% % % Copyright (c) 2003, Jochen Lenz
% % % Copyright (c) 2015, Oliver Woodford
% % % All rights reserved.
% http://www.mathworks.com/matlabcentral/fileexchange/34412-fast-and-efficient-spectral-clustering/content/files/SpectralClustering.m

function [normalizedData, slope, intersection] = normalizeData(Data)
% NORMALIZEDATA Normalized data matrix
%   normalizeData(Data) normalizes the d-by-n matrix Data, so that
%   the minimum value of each dimension and for all data points is 0 and
%   the maximum value respectively is 1.

a = 0;
b = 1;

minData = min(Data, [], 2);
maxData = max(Data, [], 2);

slope = (a-b) ./ (minData - maxData);
intersection = a - slope .* minData;

normalizedData = repmat(slope, 1, size(Data, 2)) .* Data + repmat(intersection, 1, size(Data, 2));
% size(normalizedData)
% size(Data)
% size(slope)
% size(intersection)
% 
% 
% pause