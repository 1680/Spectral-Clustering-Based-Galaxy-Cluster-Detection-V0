%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Eman Mahmoud
%%%  13 June 2016
%%% EJUST

clear all
clc
close all
rng(12345)

Data_files=dir(fullfile( 'E:\a phd\mat\MyWork\Documentaion\Results_20150818\finalizing\Final Paper\Data\tables_csv_new/*.csv'))
Data_files.name
SizeDataFiles=size(Data_files,1)

for inx=1:SizeDataFiles
    fname_files=Data_files(inx).name
    inx
    %Data=(csvimport(fname_files))
    
    %read data example: Import columns as column vectors 
    [detid,ra,dec,objID_S82,ra_S82,dec_S82,g,err_g,r,err_r,i,err_i,z,err_z,zpReis,err_zpReis,ezpR_zpR,sep_arcmin,sep_arcsec] = csvimport(fname_files, 'columns', {'detid','ra','dec','objID_S82','ra_S82','dec_S82','g','err_g','r','err_r','i','err_i','z','err_z','zpReis','err_zpReis','ezpR/zpR','sep_arcmin','sep_arcsec'});
    %remove headers
    Data=[detid,ra,dec,objID_S82,ra_S82,dec_S82,g,err_g,r,err_r,i,err_i,z,err_z,zpReis,err_zpReis,ezpR_zpR,sep_arcmin,sep_arcsec];
    dlmwrite(fname_files,Data);
end

%detid,ra,dec,objID_S82,ra_S82,dec_S82,g,err_g,r,err_r,i,err_i,z,err_z,zpReis,err_zpReis,objid_DR12,ra_DR12,dec_DR12,zp_DR12,err_zp_DR12,Mr_DR12,zs_DR12,err_zs_DR12,ezpR/zpR,sep_arcmin,sep_arcsec