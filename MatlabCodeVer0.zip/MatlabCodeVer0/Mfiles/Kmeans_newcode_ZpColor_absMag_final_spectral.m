%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Eman Mahmoud
%%%  13 June 2016
%%% EJUST

function [SelectedCluster, D_Mtrix_cluster, D_Prob_selected]= Kmeans_newcode_ZpColor_absMag_final_spectral(k,Data_ID_Contours)

% The attibutes of the galaxies in the data files:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%# 1id_CLG   2ra_CLG          3dec_CLG           4objID                 5ra              6dec               7g          8err_g         9r          10err_r 
%11i          12err_i         13z          14err_z        15zp         16err_zp    17Mr         18zs           19err_zs        [class    instrument] 
%20sep_arcmin        21sep_arcsec      22g-r                  23r-i                  24i-z                   25r-z                   

% My parameters
ID=4;RA=5;Decl=6;
Mags=[7,9,11,13];
Mag_g=7;
Mag_g_err=8;
Mag_r=9;
Mag_r_err=10;
Mag_i=11;
Mag_i_err=12;
Mag_z=13;
Mag_z_err=14;
Zp=15;
err_Zp=16;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% C H A N G E
Mr=22;
Zs=23;
err_Zs=24;
Rel_Err_Zp=25;
AngSepMin=26;
AngSepSec=27;
colors=28:33;  %all 6 combinations of colors
gr=28;ri=29;iz=30;
rz=31;gi=32;gz=33;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Data_Attributes=Data_ID_Contours(:,[Mags, colors])';%%good_1703

[normalizedData, slope, intersection] = normalizeData(Data_Attributes);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sim_type=1;
sigma=1;
Type_spectral=3;
if (sim_type==1)
    W = SimGraph_Full( normalizedData ,sigma );
elseif (sim_type==2)
    epsilon=0.1;
    W = SimGraph_Epsilon( normalizedData , epsilon );
elseif (sim_type==3)
    kk=3;
    Typ_NearestNeighbors=1;
    W = SimGraph_NearestNeighbors( normalizedData, kk, Typ_NearestNeighbors, sigma );
end

[ C_vector, c_matrix, cs, SumD, D] = SpectralClustering(W, k,Type_spectral );

size(D);
D_size=size(D,1);


for di=1:D_size
    Total=0;
    for kk=1:k
        Total=Total+(1/D(di,kk));
    end
    for kkk=1:k
        D_prob(di,kkk)=(1/D(di,kkk))/Total;
    end

end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

SumDiam=SumD';

x=size(Data_ID_Contours,2);
clust_no=x+1;
Cluster_D=x+2;
Data_ID_Contours(:,clust_no)=C_vector;
C_len=length(C_vector);
for i=1:k
    counter=0;
    clear temp
    clear Data_ID_Contours_Clusters
    Data_ID_Contours_Clusters(:,:)=Data_ID_Contours(:,1:x);
    name=sprintf('data_clusters_%d',i);
  
    for ii=1:C_len
        if Data_ID_Contours(ii,clust_no)==i
            Data_ID_Contours_Clusters(ii,clust_no)=i;
            Data_ID_Contours_Clusters(ii,Cluster_D)=D(ii,i);
            counter=counter+1;
            counter_char=char(counter);
            ii_char=char(ii);
           temp(counter,:)=Data_ID_Contours_Clusters(ii,:);
           
        else
            j=-i+3;
            Data_ID_Contours_Clusters(ii,clust_no)=j;
            Data_ID_Contours_Clusters(ii,Cluster_D)=D(ii,j);
        end
        
    end       
    eval([name  ' = temp; ']);
    galaxies_counter_vector(i)=counter;
end
galaxies_counter_vector;

for i=1:k
    ii=sprintf('%d',i);
    cluster_no=sprintf('data_clusters_%d',i);
    
    eval(['Cluster_Minimum_zp(:,' ii ') =min(' cluster_no ' (:,Zp));']);
    eval(['Cluster_Maximum_zp(:,' ii ') =max(' cluster_no ' (:,Zp));']);
    eval(['Cluster_Mean_zp(:,' ii ') =mean(' cluster_no ' (:,Zp));']);
    eval(['Cluster_Median_zp(:,' ii ') =median(' cluster_no ' (:,Zp));']);
    eval(['Cluster_Range_zp(:,' ii ') =max(' cluster_no ' (:,Zp)) - min(' cluster_no ' (:,Zp));']);
    eval(['Cluster_std_zp(:,' ii ') =std(' cluster_no ' (:,Zp));']);
    eval(['Cluster_std_r(:,' ii ') =std(' cluster_no ' (:,Mag_r));']);
    eval(['Cluster_Minimum_r(:,' ii ') =min(' cluster_no ' (:,Mag_r));']);
    eval(['Cluster_Max_r(:,' ii ') =max(' cluster_no ' (:,Mag_r));']);
    eval(['Cluster_Minimum_K_Dist(:,' ii ') =min(' cluster_no ' (:,Cluster_D));']);
    eval(['Cluster_Maximum_K_Dist(:,' ii ') =max(' cluster_no ' (:,Cluster_D));']);
    eval(['Cluster_Minimum_angsep(:,' ii ') =min(' cluster_no ' (:,AngSepMin));']);
    eval(['Cluster_Maximum_angsep(:,' ii ') =max(' cluster_no ' (:,AngSepMin));']);
    eval(['Cluster_Range_angsep(:,' ii ') =max(' cluster_no ' (:,AngSepMin)) - min(' cluster_no ' (:,AngSepMin));']);
 end
CL_mean_Zp=Cluster_Mean_zp;
CL_range_Zp=Cluster_Range_zp;
CL_min_Zp=Cluster_Minimum_zp;
CL_max_Zp=Cluster_Maximum_zp;
CL_min_angsep=Cluster_Minimum_angsep;
CL_max_angsep=Cluster_Maximum_angsep;
CL_range_angsep=Cluster_Range_angsep;
SumD;
galaxies_counter_vector;
SumD_relative=SumD./galaxies_counter_vector';
[value, index_min_r]=min(Cluster_Minimum_r);
index=index_min_r;
iii=0;
xx=size(Data_ID_Contours,1);
for i=1:xx
    if Data_ID_Contours(i,clust_no)==index
        iii=iii+1;
        SelectedCluster(iii,:)=Data_ID_Contours(i,:);
        D_Mtrix_cluster(iii,:)=D(i,index);
        D_Prob_selected(iii)=D_prob(i,index);
    end
end     
end