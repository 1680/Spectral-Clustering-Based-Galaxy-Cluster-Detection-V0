% % % Copyright (c) 2012, Ingo B�rk
% % % Copyright (c) 2003, Jochen Lenz
% % % Copyright (c) 2015, Oliver Woodford
% % % All rights reserved.
% http://www.mathworks.com/matlabcentral/fileexchange/34412-fast-and-efficient-spectral-clustering/content/files/SpectralClustering.m


function W = SimGraph_Full(M, sigma)
% SIMGRAPH_FULL Returns full similarity graph
%   Returns adjacency matrix for a full similarity graph where
%   a Gaussian similarity function with parameter sigma is
%   applied.
%
%   'M' - A d-by-n matrix containing n d-dimensional data points
%   'sigma' - Parameter for Gaussian similarity function
%

W = squareform(pdist(M','correlation'));

% Apply Gaussian similarity function
W = simGaussian(W, sigma);

end