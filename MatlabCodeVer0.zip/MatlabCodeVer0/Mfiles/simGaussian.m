% % % Copyright (c) 2012, Ingo B�rk
% % % Copyright (c) 2003, Jochen Lenz
% % % Copyright (c) 2015, Oliver Woodford
% % % All rights reserved.
% http://www.mathworks.com/matlabcentral/fileexchange/34412-fast-and-efficient-spectral-clustering/content/files/SpectralClustering.m


function [ M ] = simGaussian( M, sigma )
%SIMGAUSSIAN Calculates Gaussian similarity on matrix
%   simGaussian(M, sigma) returns a matrix of the same size as
%   the distance matrix M, which contains similarity values
%   that are computed by using a Gaussian similarity function
%   with parameter sigma.


M = exp(-M.^2 ./ (2*sigma^2));

end
