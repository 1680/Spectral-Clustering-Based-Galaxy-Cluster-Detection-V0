%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Eman Mahmoud
%%%  13 June 2016
%%% EJUST


% This is the main function for applying our spectral clustering-based cluster finding algorithm to the
% cluster sample (45) with red shifts
% The function outputs galaxy densities vector for all clusters (45) within
% both 500 kpc and 1 arcmin:

function [Density_Vector_mean_500kpc, Density_Vector_std_500kpc, Density_Vector_mean_1arcmin, Density_Vector_std_1arcmin]=MyMainFunction()
rng(12345)

% Puplished data for these clusters
Data_pub=(dlmread('.\InputData\Data_PUBLISHED_Takey2016_4.csv'));

% Data files are .csv files positioned in the DATA\sample45\ folder
addpath('.\InputData\sample45/');
Data_files=dir(fullfile( '.\InputData\sample45/*.csv'));
Data_files.name;
SizeDataFiles=size(Data_files,1);

% getting IAUNAME
fid = fopen('.\InputData\3XMM_DR5_S82_cluster_sample_mod.csv');
CC = textscan(fid, '%s%s%s%s','Delimiter',',');
fclose(fid);
CC_size=size(CC{1},1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% setting parameters
angularSep=1;
BCG_angsep=1;
measure='cosine';

k=2;
Zp_res0=0.05; %Resolution of histogram bins
prob_ini=0.8;%Probability of each galaxy being a member in cluster (Depends on distance matrix D)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The attibutes of the galaxies in the data files:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%1id_CLG   2ra_CLG          3dec_CLG           4objID                 5ra              6dec               7g          8err_g         9r          10err_r 
%11i          12err_i         13z          14err_z        15zp         16err_zp    17Mr         18zs           19err_zs        [class    instrument] 
%20sep_arcmin        21sep_arcsec      22g-r                  23r-i                  24i-z                   25r-z                   

% My parameters
ID=4;RA=5;Decl=6;
Mags=[7,9,11,13];
Mag_g=7;
Mag_g_err=8;
Mag_r=9;
Mag_r_err=10;
Mag_i=11;
Mag_i_err=12;
Mag_z=13;
Mag_z_err=14;
Zp=15;
err_Zp=16;
% C H A N G E
Mr=22;
Zs=23;
err_Zs=24;
Rel_Err_Zp=25;
AngSepMin=26;
AngSepSec=27;
colors=28:33;  %all 6 combinations of colors
gr=28;ri=29;iz=30;
rz=31;gi=32;gz=33;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Saving results to files
PR_out_final = fopen(fullfile('OutputResults','Table1_Results_ClusterSample45.csv'),'w');
fprintf(PR_out_final, '%s, %s, %s , %s, %s, %s,%s, %s,%s, %s, %s , %s, %s \n', 'IAUNAME', 'RA_Xray', 'DEC_Xray', 'DETID' ,'RA_BCG','DEC_BCG','n_zp', 'z_p' ,'n_zs', 'z_s','Z_pub', 'BCGoffset_arcmin', 'BCGoffset_kpc');

inx2=0;
tic
for inx=1:SizeDataFiles
    Data=[];
    SelectedCluster=[];
    fname_files=Data_files(inx).name;
     fid = fopen(fname_files);
     C = textscan(fid, '%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s','Delimiter',',');
     fclose(fid);
     Data=(dlmread(fname_files));
    pat = '\d*';
    str = fname_files;
    fname_files_ID = regexp(str, pat, 'match');
    fname_files_ID2= char(fname_files_ID(1));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    n=size(Data,1);
    n_vector(inx)=n;
    % Calculating colors from magnitudes
    %gr
    Data(:,gr)=(Data(:,Mag_g)-Data(:,Mag_r));
    %ri
    Data(:,ri)=(Data(:,Mag_r)-Data(:,Mag_i));
    %iz
    Data(:,iz)=(Data(:,Mag_i)-Data(:,Mag_z));
    %rz
    Data(:,rz)=(Data(:,Mag_r)-Data(:,Mag_z));
    %gi
    Data(:,gi)=(Data(:,Mag_g)-Data(:,Mag_i));
    %gz
    Data(:,gz)=(Data(:,Mag_g)-Data(:,Mag_z));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     H0=70; %Hubble constant(km/sec/Mpc)
    OmegaM=0.3; %Matter
    OmegaV=0.7; %Vaccum
    
    
    Data_ID_Contours=[];
        ii=0;
        for i=1:n
%            % Filtering the data
            if Data(i,AngSepMin)<angularSep && Data(i,Rel_Err_Zp)<0.5  && Data(i,Mag_i)<23 && Data(i,Mag_i_err)<0.3 && Data(i,Zp)>0.03 && Data(i,Zp)<1 ...
                    && Data(i,Mag_g)<25 && Data(i,Mag_r)<25 && Data(i,Mag_z)<25
                ii=ii+1;
                Data_ID_Contours(ii,:)=Data(i,:);
            end

        end
    nn=size(Data_ID_Contours,1);
    nn_vector(inx)=nn;
    
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      [SelectedCluster2, D_Mtrix_cluster, D_Prob_selected]= Kmeans_newcode_ZpColor_absMag_final_spectral(k,Data_ID_Contours);
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
        iinn=0;
        for ooo=1:size(SelectedCluster2,1)
            if D_Prob_selected(ooo)>=prob_ini
                iinn=iinn+1;
                SelectedCluster(iinn,:)=SelectedCluster2(ooo,:);
            end
        end
        
        Galaxy_excluded(inx)=size(SelectedCluster2,1)-size(SelectedCluster,1);
        SizeB4Exclud(inx)=size(SelectedCluster2,1);
        SizeA4Exclud(inx)=size(SelectedCluster,1);
        exclude_per_median=(median(Galaxy_excluded./SizeB4Exclud))*100;
        
        
        
        Zp_res=Zp_res0;
        h=hist(SelectedCluster(:,Zp),0:Zp_res:1);
        [PKS,LOCS]=findpeaks(h);
        [PKS_max,LOCS_max]=max(PKS);
        LOCS2=LOCS(LOCS_max);
        Zp_hist(inx)=((LOCS2-1)/(1/Zp_res))-(Zp_res/2);
        
      Zp_Xaxis=(Zp_res/2):Zp_res:(1+((Zp_res/2)));        
        f = fit(Zp_Xaxis.',h.','gauss1');
        Zp_hist_fit(inx)=f.b1;
        Zp_hist_fit_sigma(inx)=f.c1;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    C_len=size(SelectedCluster,1);
    Data_error_Zp=SelectedCluster(:,err_Zp);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Data_angsep=SelectedCluster(:,AngSepMin);
    Data_clusdist=D_Mtrix_cluster;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        N_Zp=size(SelectedCluster,1);
            W_Zp=1./(Data_error_Zp.^2);            
            sum_W_Zp=sum(W_Zp);
            W_norm_Zp=W_Zp./sum_W_Zp;
            sum_W_norm_Zp=sum(W_Zp.*log(SelectedCluster(:,Zp)));
            sum_W_norm_Zp2=sum(W_Zp./SelectedCluster(:,Zp));
        mean_Zp=mean(SelectedCluster(:,Zp));
        median_Zp=median(SelectedCluster(:,Zp));
        mod_Zp=mode(SelectedCluster(:,Zp));
        geo_mean_Zp=geomean(SelectedCluster(:,Zp));
        harm_mean_Zp=harmmean(SelectedCluster(:,Zp));
        std_Zp=std(SelectedCluster(:,Zp));
        geo_std_Zp=exp(std(log(SelectedCluster(:,Zp)))+mean(log(SelectedCluster(:,Zp))));
        W_avg_Zp(inx)=sum(W_norm_Zp.*SelectedCluster(:,Zp));
        geo_W_avg_Zp=exp(sum_W_norm_Zp / sum_W_Zp);
        harm_W_avg_Zp=(sum_W_Zp/sum_W_norm_Zp2);
        err_W_avg_Zp=1/sum_W_Zp;
        mad_Zp=mad(SelectedCluster(:,Zp),1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        [Min_r,Index_r]=min(SelectedCluster(:,9));
        Zs_check_min_r=(SelectedCluster(Index_r,Zs));
        if Zs_check_min_r<0
            Zs_BCG=(SelectedCluster(Index_r,Zp));
        else
           Zs_BCG= Zs_check_min_r;
        end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        sub_Zs=SelectedCluster(SelectedCluster(:,Zs)>0,:);
            N_Zs=size(sub_Zs,1);
            Data_error_Zs=sub_Zs(:,err_Zs);
            W_Zs=1./(Data_error_Zs.^2);
            sum_W_Zs=sum(W_Zs);
            sum_W_norm_Zs=sum(W_Zs.*log(sub_Zs(:,Zs)));
            W_norm_Zs=W_Zs./sum_W_Zs;
        mean_Zs=mean(sub_Zs(:,Zs));
        geo_mean_Zs=geomean(sub_Zs(:,Zs));
        median_Zs=median(sub_Zs(:,Zs));
       std_Zs=(std((sub_Zs(:,Zs))));
        geo_std_Zs=exp(std(log(sub_Zs(:,Zs))));
        W_avg_Zs=sum(W_norm_Zs.*sub_Zs(:,Zs));
        geo_W_avg_Zs=exp(sum_W_norm_Zs / sum_W_Zs);
        err_W_avg_Zs=1/sum_W_Zs;
        
    z_pub(inx)=Data_pub(inx,5);
    error_zp_w_avg(inx)=abs(z_pub(inx)-W_avg_Zp(inx));
    error_zp_hist(inx)=abs(z_pub(inx)-Zp_hist(inx));
    error_zp_hist_fit(inx)=abs(z_pub(inx)-Zp_hist_fit(inx));
        
        if W_avg_Zs ~= 0
            inx2=inx2+1;
            error_zs2(inx2)=abs(z_pub(inx)-W_avg_Zs);
            error_zs(inx)=abs(z_pub(inx)-W_avg_Zs);
        else
            error_zs(inx)=0;
        end
        
        
    % F I N A L %
    % F I N A L %
    % F I N A L %
    % F I N A L %
    % F I N A L %
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %STEP(1)
    Z_tent=Zp_hist(inx);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %STEP(2)
    %physical distance calculations
    [phdist, scale]=angsepnZp2phdist(H0,OmegaM,OmegaV,Z_tent,1);
    %scale: Kpc/Arcsec
    %Physical distance=500Kpc
    scale_matrix(inx)=scale;
    angular_radius_tent=(500/scale)/60;  %arcmin
      
    
    ii=0;
    Data_ID_Contours_Zp=[];
        for i=1:n
            if Data(i,AngSepMin)<angular_radius_tent && Data(i,Zp)<(Z_tent+0.04*(1+Z_tent)) && Data(i,Zp)>(Z_tent-0.04*(1+Z_tent))  && Data(i,Rel_Err_Zp)<0.5 && Data(i,Mag_i)<23 && Data(i,Mag_i_err)<0.3 && Data(i,Zp)>0.03 && Data(i,Zp)<1 ...
                    && Data(i,Mag_g)<25 && Data(i,Mag_r)<25 && Data(i,Mag_z)<25
                ii=ii+1;
                Data_ID_Contours_Zp(ii,:)=Data(i,:);
                C_Zp{ii}=C{4}{i};
            end
        end
    nZp=size(Data_ID_Contours_Zp,1);
    nZp_Vector(inx)=nZp;
    
     if nZp==0
        mean_Zp=0;
        median_Zp=0;
        std_Zp=0;
        W_avg_Zp2=0;
        err_W_avg_Zp=0;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        sub_Zs_Zp=1;
        mean_Zs_Zp=0;
        median_Zs_Zp=0;
        std_Zs_Zp=0;
        W_avg_Zs_Zp=0;
        err_W_avg_Zs_Zp=0;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        N_Zs_Zp=0;
     else
    
    Data_error_Zp=Data_ID_Contours_Zp(:,err_Zp);
            W_Zp=1./(Data_error_Zp.^2);
            sum_W_Zp=sum(W_Zp);
            sum_W_norm_Zp=sum(W_Zp.*log(Data_ID_Contours_Zp(:,Zp)));
                       
            W_norm_Zp=W_Zp/sum_W_Zp;
        mean_Zp=mean(Data_ID_Contours_Zp(:,Zp));
        median_Zp=median(Data_ID_Contours_Zp(:,Zp));
        std_Zp=std(Data_ID_Contours_Zp(:,Zp));
        W_avg_Zp2=sum(W_norm_Zp.*Data_ID_Contours_Zp(:,Zp));
        err_W_avg_Zp=1/sum_W_Zp;  
    % C
    % Zs for Zp
        sub_Zs_Zp=Data_ID_Contours_Zp(Data_ID_Contours_Zp(:,Zs)>0,:);
       
            N_Zs_Zp=size(sub_Zs_Zp,1);
            Data_error_Zs_Zp=sub_Zs_Zp(:,err_Zs);
            W_Zs_Zp=1./(Data_error_Zs_Zp.^2);
            sum_W_Zs_Zp=sum(W_Zs_Zp);
            W_norm_Zp_Zs=W_Zs_Zp/sum_W_Zs_Zp;
                        
            sum_W_norm_Zs_Zp=sum(W_Zs_Zp.*log(sub_Zs_Zp(:,Zs)));
        mean_Zs_Zp=mean(sub_Zs_Zp(:,Zs));
        median_Zs_Zp=median(sub_Zs_Zp(:,Zs));
         std_Zs_Zp=std(sub_Zs_Zp(:,Zs));
        W_avg_Zs_Zp=sum(W_norm_Zp_Zs.*sub_Zs_Zp(:,Zs));
        err_W_avg_Zs_Zp=1/sum_W_Zs_Zp;
           
     end
    W_mean_zp_500kpc(inx)=W_avg_Zp2;
    W_mean_zs_500kpc(inx)=W_avg_Zs_Zp;
    tempZp=0;
    W_avg_Zp2;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Begin Second Iteration
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    diff=abs(tempZp-W_avg_Zp2);
    while abs ((tempZp-W_avg_Zp2))>0.001
    inx;
    tempZp=W_avg_Zp2;
      [phdist, scale]=angsepnZp2phdist(H0,OmegaM,OmegaV,W_avg_Zp2,1);
    %scale: Kpc/Arcsec
    %Physical distance=500Kpc
    scale_matrix(inx)=scale;
    angular_radius2=(500/scale)/60;  %arcmin

                ii=0;
                Data_ID_Contours_Zp=[];
                    for i=1:n
                        if Data(i,AngSepMin)<angular_radius2 && Data(i,Zp)<(W_avg_Zp2+0.04*(1+W_avg_Zp2)) && Data(i,Zp)>(W_avg_Zp2-0.04*(1+W_avg_Zp2))  && Data(i,Rel_Err_Zp)<0.5 && Data(i,Mag_i)<23 && Data(i,Mag_i_err)<0.3 && Data(i,Zp)>0.03 && Data(i,Zp)<1 ...
                    && Data(i,Mag_g)<25 && Data(i,Mag_r)<25 && Data(i,Mag_z)<25
                            ii=ii+1;
                            Data_ID_Contours_Zp(ii,:)=Data(i,:);
                            C_Zp{ii}=C{4}{i};
                        end
                    end
                nZp=size(Data_ID_Contours_Zp,1);
                nZp_Vector(inx)=nZp;
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     if nZp==0
        mean_Zp=0;
        median_Zp=0;
        std_Zp=0;
        W_avg_Zp2=0;
        err_W_avg_Zp=0;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        sub_Zs_Zp=1;
        mean_Zs_Zp=0;
        median_Zs_Zp=0;
        std_Zs_Zp=0;
        W_avg_Zs_Zp=0;
        err_W_avg_Zs_Zp=0;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        N_Zs_Zp=0;
     else
    Data_error_Zp=Data_ID_Contours_Zp(:,err_Zp);
            W_Zp=1./(Data_error_Zp.^2);
            sum_W_Zp=sum(W_Zp);
            sum_W_norm_Zp=sum(W_Zp.*log(Data_ID_Contours_Zp(:,Zp)));
                       
            W_norm_Zp=W_Zp/sum_W_Zp;
        mean_Zp=mean(Data_ID_Contours_Zp(:,Zp));
        median_Zp=median(Data_ID_Contours_Zp(:,Zp));
        std_Zp=std(Data_ID_Contours_Zp(:,Zp));
        W_avg_Zp2=sum(W_norm_Zp.*Data_ID_Contours_Zp(:,Zp));
        err_W_avg_Zp=1/sum_W_Zp;
        sub_Zs_Zp=Data_ID_Contours_Zp(Data_ID_Contours_Zp(:,Zs)>0,:);
       
            N_Zs_Zp=size(sub_Zs_Zp,1);
            Data_error_Zs_Zp=sub_Zs_Zp(:,err_Zs);
            W_Zs_Zp=1./(Data_error_Zs_Zp.^2);
            sum_W_Zs_Zp=sum(W_Zs_Zp);
            W_norm_Zp_Zs=W_Zs_Zp/sum_W_Zs_Zp;
                        
            sum_W_norm_Zs_Zp=sum(W_Zs_Zp.*log(sub_Zs_Zp(:,Zs)));
        mean_Zs_Zp=mean(sub_Zs_Zp(:,Zs));
        median_Zs_Zp=median(sub_Zs_Zp(:,Zs));
       std_Zs_Zp=std(sub_Zs_Zp(:,Zs));
        W_avg_Zs_Zp=sum(W_norm_Zp_Zs.*sub_Zs_Zp(:,Zs));
        err_W_avg_Zs_Zp=1/sum_W_Zs_Zp;
               
     end
    W_mean_zp_500kpc(inx)=W_avg_Zp2;
    W_mean_zs_500kpc(inx)=W_avg_Zs_Zp;
    W_avg_Zp2;
    diff=abs(tempZp-W_avg_Zp2);
end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % End Second Iteration
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % Galaxy Density within one arcmin
                i_1arc=0;
                Data_ID_1arcmin=[];
                    for i=1:n
                        if Data(i,AngSepMin)<1 && Data(i,Zp)<(W_avg_Zp2+0.04*(1+W_avg_Zp2)) && Data(i,Zp)>(W_avg_Zp2-0.04*(1+W_avg_Zp2))  && Data(i,Rel_Err_Zp)<0.5 && Data(i,Mag_i)<23 && Data(i,Mag_i_err)<0.3 && Data(i,Zp)>0.03 && Data(i,Zp)<1 ...
                    && Data(i,Mag_g)<25 && Data(i,Mag_r)<25 && Data(i,Mag_z)<25
                            i_1arc=i_1arc+1;
                            Data_ID_1arcmin(i_1arc,:)=Data(i,:);
                            C_Zp{i_1arc}=C{4}{i};
                        end

                    end
                nZp_1arcmin=size(Data_ID_1arcmin,1);
                nZp_1arcmin_Vector(inx)=nZp_1arcmin;
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                 if nZp==0
                    mean_Zp=0;
                    median_Zp=0;
                    std_Zp=0;
                    W_avg_Zp2=0;
                    err_W_avg_Zp=0;
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    sub_Zs_Zp=1;
                    mean_Zs_Zp=0;
                    median_Zs_Zp=0;
                    std_Zs_Zp=0;
                    W_avg_Zs_Zp=0;
                    err_W_avg_Zs_Zp=0;
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    N_Zs_Zp=0;
                else
                Data_error_Zp=Data_ID_Contours_Zp(:,err_Zp);
                        W_Zp=1./(Data_error_Zp.^2);
                        sum_W_Zp=sum(W_Zp);
                        sum_W_norm_Zp=sum(W_Zp.*log(Data_ID_Contours_Zp(:,Zp)));
                        W_norm_Zp=W_Zp/sum_W_Zp;
                    mean_Zp=mean(Data_ID_Contours_Zp(:,Zp));
                    median_Zp=median(Data_ID_Contours_Zp(:,Zp));
                    std_Zp=std(Data_ID_Contours_Zp(:,Zp));
                    W_avg_Zp2=sum(W_norm_Zp.*Data_ID_Contours_Zp(:,Zp));
                    err_W_avg_Zp=1/sum_W_Zp;
                % C
                % Zs for Zp
                    sub_Zs_Zp=Data_ID_Contours_Zp(Data_ID_Contours_Zp(:,Zs)>0,:);

                        N_Zs_Zp=size(sub_Zs_Zp,1);
                        Data_error_Zs_Zp=sub_Zs_Zp(:,err_Zs);
                        W_Zs_Zp=1./(Data_error_Zs_Zp.^2);
                        sum_W_Zs_Zp=sum(W_Zs_Zp);
                        W_norm_Zp_Zs=W_Zs_Zp/sum_W_Zs_Zp;

                        sum_W_norm_Zs_Zp=sum(W_Zs_Zp.*log(sub_Zs_Zp(:,Zs)));
                    mean_Zs_Zp=mean(sub_Zs_Zp(:,Zs));
                    median_Zs_Zp=median(sub_Zs_Zp(:,Zs));
                   std_Zs_Zp=std(sub_Zs_Zp(:,Zs));
                    W_avg_Zs_Zp=sum(W_norm_Zp_Zs.*sub_Zs_Zp(:,Zs));
                    err_W_avg_Zs_Zp=1/sum_W_Zs_Zp;
                 end
                W_mean_zp_500kpc(inx)=W_avg_Zp2;
                W_mean_zs_500kpc(inx)=W_avg_Zs_Zp;
                
    % S T E P 8
    % BCG position
    [BCG_r,Index_BCG]=min(Data_ID_Contours_Zp(:,Mag_r));
    RA_BCG=Data_ID_Contours_Zp(Index_BCG,RA);
    DEC_BCG=Data_ID_Contours_Zp(Index_BCG,Decl);


    [phdist, scale]=angsepnZp2phdist(H0,OmegaM,OmegaV,W_avg_Zp2,1);
    %scale: Kpc/Arcsec
    BCG_scale_matrix(inx)=scale;
    angular_radius_final(inx)=(500/scale)/60;  %arcmin
    
    BCGoffset(inx)= calcAngSepDeg(RA_BCG, DEC_BCG, Data_pub(inx,2), Data_pub(inx,3));
    BCGoffset_arcmin(inx)=BCGoffset(inx)*60;
    %scale: Kpc/Arcsec
    BCGoffset_Kpc(inx)=BCG_scale_matrix(inx)*BCGoffset_arcmin(inx)*60;
  
    %%% IAU DATA
    for myLoop=1:CC_size
        if CC{1}{myLoop}==fname_files_ID2
            IAUname=CC{2}{myLoop};
            RA_Xray=CC{3}{myLoop};
            DEC_Xray=CC{4}{myLoop};
            break;
        end
    end
    
        fprintf(PR_out_final, '%s, %s , %s, %s, %f , %f, %f, %f , %f, %f , %f, %f , %f\n',IAUname, RA_Xray, DEC_Xray, fname_files_ID2, RA_BCG, DEC_BCG,nZp, W_avg_Zp2 ,N_Zs_Zp, W_avg_Zs_Zp, z_pub(inx), BCGoffset_arcmin(inx), BCGoffset_Kpc(inx));

end
toc
fclose(PR_out_final);

x_zp_w_avg=(error_zp_w_avg<=0.1);
x_zp_hist=(error_zp_hist<=0.1);
x_zp_hist_fit=(error_zp_hist_fit<=0.1);
x_zs=(error_zs2<=0.05);

zp_statstics_hist=size(x_zp_hist(x_zp_hist==1),2)
zp_statstics_percent_hist=(zp_statstics_hist/inx)*100


fprintf('Press Enter to plot the z_p versus z_s relation: \n')
pause
figure;plot([0:0.1:0.9],[0:0.1:0.9]);hold on; plot(W_mean_zp_500kpc,W_mean_zs_500kpc,'.r');grid;xlabel('z_p');ylabel('z_s');xlim([0 0.9]);ylim([0 0.9]); hold off
saveas(gca,'.\OutputResults\Fig3_Zp_Zs_ClusterSample','jpeg');


fprintf('Press Enter to plot the z_p versus z_pub relation: \n')
pause
figure;plot([0:0.1:0.9],[0:0.1:0.9]);hold on; plot(W_mean_zp_500kpc,z_pub,'.r');grid;xlabel('z_p');ylabel('z_{pub}');xlim([0 0.9]);ylim([0 0.9]); hold off
saveas(gca,'.\OutputResults\Fig4_Zp_Zpub_ClusterSample','jpeg');


fprintf('Press Enter to plot BCG offset in arcmins: \n')
pause
figure;hist(BCGoffset_arcmin,0.125:0.25:4);grid;xlabel('BCG offset in arcmins');ylabel('clusters counts');xlim([0 4]);ylim([0 30]);
saveas(gca,'.\OutputResults\Fig5_BCGoffset_arcmin','jpeg');

fprintf('Press Enter to plot BCG offset in kpc: \n')
pause
figure;hist(BCGoffset_Kpc,12.5:25:550);grid;xlabel('BCG offset in kpc');ylabel('clusters counts');xlim([0 550]);ylim([0 11]);
saveas(gca,'.\OutputResults\Fig5_BCGoffset_kpc','jpeg');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% calculating galaxy densities for all clusters (45) within both 500 kpc and 1 arcmin:
Density_Vector=(nZp_Vector./(pi*(angular_radius_final.^2)));
Density_Vector_1arcmin=(nZp_1arcmin_Vector/pi); % the galaxy density is the same as the count but divided by pi  

both=[Density_Vector' W_mean_zp_500kpc' nZp_Vector'];
both_1arcmin=[Density_Vector_1arcmin' W_mean_zp_500kpc' nZp_1arcmin_Vector'];

    for interval_index=1:7 % 7 intervals (0.1:0.1:0.8)
        temp1=[];
        temp2=[];
        temp1=both(both(:,2)>(interval_index/10),:);
        if interval_index<7
            temp2=temp1(temp1(:,2)<=(interval_index+1)/10,:);
        else
            temp2=temp1;
        end
        ss_temp(interval_index)=size(temp2,1);
        Density_Vector_mean_500kpc(interval_index)=mean(temp2(:,1));
        Density_Vector_std_500kpc(interval_index)=std(temp2(:,1));
        Density_Vector_median(interval_index)=median(temp2(:,1));
        temp1_1arcmin=[];
        temp2_1arcmin=[];
        temp1_1arcmin=both_1arcmin(both_1arcmin(:,2)>(interval_index/10),:);
        %temp2_1arcmin=temp1_1arcmin(temp1_1arcmin(:,2)<=(interval_index+1)/10,:);
        if interval_index<7
            temp2_1arcmin=temp1_1arcmin(temp1_1arcmin(:,2)<=(interval_index+1)/10,:);
        else
            temp2_1arcmin=temp1_1arcmin;
        end
        ss_temp_1arcmin(interval_index)=size(temp2_1arcmin,1);
        Density_Vector_mean_1arcmin(interval_index)=mean(temp2_1arcmin(:,1));
        Density_Vector_std_1arcmin(interval_index)=std(temp2_1arcmin(:,1));
        Density_Vector_median_1arcmin(interval_index)=median(temp2_1arcmin(:,1));                
    end
    x=1;
end





