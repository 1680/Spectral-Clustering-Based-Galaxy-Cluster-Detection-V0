%%% James Schombert has written a Python version of this calculator.
%%% http://www.astro.ucla.edu/~wright/CosmoCalc.html
%%% http://www.astro.ucla.edu/~wright/CC.python


function r = calcAngSepDeg(RADeg1, decDeg1, RADeg2, decDeg2)

%Calculates the angular separation of two positions on the sky (specified 
%in decimal degrees) in decimal degrees, assuming a tangent plane projection 
%(so separation has to be <90 deg). Note that RADeg2, decDeg2 can be numpy 
%arrays. 


cRA = degtorad(RADeg1); 
cDec = degtorad(decDeg1);   
gRA = degtorad(RADeg2); 
gDec = degtorad(decDeg2); 
  
dRA = cRA-gRA ;
dDec = gDec-cDec; 
cosC = ((sin(gDec)*sin(cDec)) + (cos(gDec)*cos(cDec) * cos(gRA-cRA))); 
x = (cos(cDec)*sin(gRA-cRA))/cosC ;
y = (((cos(gDec)*sin(cDec)) - (sin(gDec) * cos(cDec) *cos(gRA-cRA)))/cosC) ;
r = radtodeg(sqrt(x*x+y*y));