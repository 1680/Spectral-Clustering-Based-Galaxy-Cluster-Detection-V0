%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Eman Mahmoud
%%%  13 June 2016
%%% EJUST

% This is the function for investigating random positions (100)

function x=RandomGalaxyDensity_500kpc(Density_Vector_mean, Density_Vector_std)

rng(12345)

Z_tent_res=0.1;

addpath('.\InputData\RandomPositions100/');
Data_files=dir(fullfile( '.\InputData\RandomPositions100/*.csv'))
Data_files.name;
SizeDataFiles=size(Data_files,1);


%# 1id_CLG   2ra_CLG          3dec_CLG           4objID                 5ra              6dec               7g          8err_g         9r          10err_r 
%11i          12err_i         13z          14err_z        15zp         16err_zp    17Mr         18zs           19err_zs        [class    instrument] 
%20sep_arcmin        21sep_arcsec      22g-r                  23r-i                  24i-z                   25r-z                   

ID=4;
RA=5;
Decl=6;
%Mags=[7,9,11,13];
Mags=[7,9,11,13];
Mag_g=7;
Mag_r=9;
Mag_r_err=10;
Mag_i=11;
Mag_i_err=12;
Mag_z=13;
Zp=15;
err_Zp=16;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% C H A N G E
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Rel_Err_Zp=25;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
AngSepMin=26;
AngSepSec=27;
%colors=28:33;  %all combinations of colors
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% 
% fname=sprintf('Out_20160121_ZpColor_filter_Zp500Zs500_Random.csv');
% PR_out_filter_Zp500Zs500_Random = fopen(fname,'w');
% fprintf(PR_out_filter_Zp500Zs500_Random, '%s, %s , %s , %s , %s, %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s\n', 'Cluster Name' ,'RA_BCG','DEC_BCG','Cluster Size' , 'angular_radius' , 'N_Zp', 'mean_Zp' , 'median_Zp' , 'std_Zp' , 'W_mean_zp_500kpc' , 'err_W_avg_Zp_err', 'N_Zs', 'mean_Zs' , 'median_Zs','std_Zs','W_mean_zs_500kpc','err_W_avg_Zs', 'Z_pub');

inx2=0;
tic

for inx=1:SizeDataFiles
    Data=[];
    SelectedCluster=[];
    fname_files=Data_files(inx).name;
fid = fopen(fname_files);
 C = textscan(fid, '%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s','Delimiter',',');
 fclose(fid);
%  C(ID)
%  pause
    
 %   eval(['Data=(dlmread(''E:\a phd\mat\Data\Final_csv_tables\sample54/' fname_files '''));'])
 Data=(dlmread(fname_files));
%     size(Data)
%     pause
    pat = '\d*';
    str = fname_files;
    %is1=ischar(fname_files)
    fname_files_ID = regexp(str, pat, 'match');
    fname_files_ID2= char(fname_files_ID(1));
%

 n=size(Data,1);
    n_vector(inx)=n;
%     Data(:,ID)
%     pause
%     Data(:,22)=abs(Data(:,22));
%     Data(:,23)=abs(Data(:,22));
%     Data(:,24)=abs(Data(:,22));
%     
    %gr
    H0=70; %Hubble constant(km/sec/Mpc)
    OmegaM=0.3; %Matter
    OmegaV=0.7; %Vaccum
    
    
    angularSep=1;
Data_ID_Contours=[];
        ii=0;
        for i=1:n
%             Data(i,AngSepMin)
%             Data(i,Mag_r)
%             Data(i,Rel_Err_Zp)
%             pause
            %if Data(i,AngSepMin)<angularSep && Data(i,Rel_Err_Zp)<0.5  && Data(i,Mag_r)<23.26 && Data(i,Mag_r_err)<0.28 %&& Data(i,Zp)<0.8
          if Data(i,AngSepMin)<angularSep && Data(i,Rel_Err_Zp)<0.5  && Data(i,Mag_i)<23 && Data(i,Mag_i_err)<0.3 && Data(i,Zp)>0.03 && Data(i,Zp)<1 ...
                    && Data(i,Mag_g)<25 && Data(i,Mag_r)<25 && Data(i,Mag_z)<25

                ii=ii+1;
                Data_ID_Contours(ii,:)=Data(i,:);
            end

        end
    nn=size(Data_ID_Contours,1);
    nn_vector(inx)=nn;
    
    
    % F I N A L %
    % F I N A L %
    % F I N A L %
    % F I N A L %
    % F I N A L %
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %STEP(1)
%     W_avg_Zs=W_avg_Zs
%     W_avg_Zp=W_avg_Zp

%     Z_tent=W_avg_Zs;
%     if isnan(Z_tent)
%         Z_tent=W_avg_Zp(inx);
%     end;
Z_index=0;
Z_tent=0;
Z_tent_fin=1;
while Z_tent<Z_tent_fin
    
    Z_index=Z_index+1;
    Z_tent=Z_tent+Z_tent_res;
    Z_tent_matrix(Z_index)=Z_tent;
    
%     Z_tent
%     pause
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %STEP(2)
    %physical distance calculations
   
    
    [phdist, scale]=angsepnZp2phdist(H0,OmegaM,OmegaV,Z_tent,1);
    %scale: Kpc/Arcsec
    %Physical distance=500Kpc
    Z_tent;
    scale;
    
    
    angular_radius=(500/scale)/60;  %arcmin
    angular_radius_matrix(inx,Z_index)=angular_radius;
    
    
       ii=0;
    Data_ID_Contours_Zp=[];
        for i=1:n
            if Data(i,AngSepMin)<angular_radius && Data(i,Zp)<(Z_tent+0.04*(1+Z_tent)) && Data(i,Zp)>(Z_tent-0.04*(1+Z_tent))  && Data(i,Rel_Err_Zp)<0.5 && Data(i,Mag_i)<23 && Data(i,Mag_i_err)<0.3 && Data(i,Zp)<1 && Data(i,Zp)>0.03  ...
                    && Data(i,Mag_g)<25 && Data(i,Mag_r)<25 && Data(i,Mag_z)<25
            ii=ii+1;
                Data_ID_Contours_Zp(ii,:)=Data(i,:);
                C_Zp{ii}=C{4}{i};
            end

        end
    nZp=size(Data_ID_Contours_Zp,1);
%     pause
    
     if nZp==0
        mean_Zp=0;
        median_Zp=0;
        std_Zp=0;
        W_avg_Zp2=0;
        err_W_avg_Zp=0;
       
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        sub_Zs_Zp=1;
        
        mean_Zs_Zp=0;
        median_Zs_Zp=0;
        std_Zs_Zp=0;
        W_avg_Zs_Zp=0;
        err_W_avg_Zs_Zp=0;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        N_Zs_Zp=0;
     
    else
    
    Data_error_Zp=Data_ID_Contours_Zp(:,err_Zp);
            W_Zp=1./(Data_error_Zp.^2);
            sum_W_Zp=sum(W_Zp);
            sum_W_norm_Zp=sum(W_Zp.*log(Data_ID_Contours_Zp(:,Zp)));
                       
            W_norm_Zp=W_Zp/sum_W_Zp;
        %mean_Zp=geomean(Data_ID_Contours_Zp(:,Zp));
        mean_Zp=mean(Data_ID_Contours_Zp(:,Zp));
        median_Zp=median(Data_ID_Contours_Zp(:,Zp));
        %std_Zp=exp(std(log(SelectedCluster(:,Zp))))
        %std_Zp=nthroot(exp(std(log(SelectedCluster(:,Zp)))),N_Zp)
        %std_Zp=exp(std(log(Data_ID_Contours_Zp(:,Zp)))+mean(log(Data_ID_Contours_Zp(:,Zp))));
        std_Zp=std(Data_ID_Contours_Zp(:,Zp));
        %W_avg_Zp2=exp(sum_W_norm_Zp / sum_W_Zp);
        W_avg_Zp2=sum(W_norm_Zp.*Data_ID_Contours_Zp(:,Zp));
        err_W_avg_Zp=1/sum_W_Zp;
    
        
     end
    N_zp_500kpc(inx,Z_index)=nZp;
    
%     N_zs_500kpc(inx,Z_index)=N_Zs_Zp;

end
   
end
toc

%%%% Galaxy Density per arcmin^2
N_Zp_Density=N_zp_500kpc./(pi*(angular_radius_matrix.^2));
D_N_zp_500kpc_median=median(N_Zp_Density,1);
D_N_zp_500kpc_mean=mean(N_Zp_Density,1);
D_N_zp_500kpc_std=std(N_Zp_Density,1);
D_N_zp_500kpc_mad=mad(N_Zp_Density);
D_vector=angular_radius_matrix(1,:);
% % % % % % % % % Data_ID_Contours_Zp
% % % % % % % % % xx=DensityAreaFn2_new(Data_ID_Contours_Zp, zp_max, nbins_zp, nbins_angsep);
% fclose(PR_out);
% fclose(PR_out_filter_Zp500Zs500_Random);
N_zp_500kpc_median=median(N_zp_500kpc,1);
N_zp_500kpc_mean=mean(N_zp_500kpc,1);
N_zp_500kpc_std=std(N_zp_500kpc,1);
N_zp_500kpc_mad=mad(N_zp_500kpc);

temp=[Z_tent_matrix' median(N_zp_500kpc,1)'];
 save('newstruct', 'temp' ,'-ascii');
 
both=[N_zp_500kpc_mean' N_zp_500kpc_std'];
% figure
% bar(Z_tent_matrix,both,'stacked');grid;xlabel('Zp');ylabel('Mean Galaxy Count');xlim([0 1]);ylim([0 25]);

both2=[N_zp_500kpc_median' N_zp_500kpc_mad'];
% figure
% bar(Z_tent_matrix,both2,'stacked');grid;xlabel('Zp');ylabel('Median Galaxy Count');xlim([0 1]);ylim([0 25]);


% Density_Vector_mean = [0.72
%           1.82
%           1.97
%           2.63
%           3.19
%           3.30
%           4.39]';
%       
%       
%  Density_Vector_std=[0.33
%           0.83
%           0.62
%           0.71
%           1.47
%           1.50
%              2.91]';
diff=(Density_Vector_mean-Density_Vector_std);
     
both3=[D_N_zp_500kpc_mean'];

 ii=0;
 Thershold=D_N_zp_500kpc_mean+3*D_N_zp_500kpc_std;
  
 for i=1:SizeDataFiles
    for iii=1:11
         if (N_Zp_Density(i,iii)<=Thershold(iii))
             ii=ii+1;
          D_N_zp_500kpc_filtered_mean(i,iii)=N_Zp_Density(i,iii);
         else
          D_N_zp_500kpc_filtered_mean(i,iii)=Inf;

         end
    
    end
%     end

 end
 n_filtered_mean=size(D_N_zp_500kpc_filtered_mean);
 for o=1:11
     D=D_N_zp_500kpc_filtered_mean(:,o);
     DD=D(D<Inf);
     DD_size(o)=size(DD,1);
     D_N_zp_500kpc_mean_filtered(o)=mean(DD);
     D_N_zp_500kpc_std_filtered(o)=std(DD);
     
 end
%  DD_size
 both_filtered=[D_N_zp_500kpc_mean_filtered'];
figure
hold on
%bar(Z_tent_matrix,both_filtered,'stacked');grid;xlabel('Zp');ylabel('Mean Galaxy Count Filtered');xlim([0 1]);ylim([0 20]);
%bar(0.15:0.1:0.75,[diff' Density_Vector_std'],'stacked','w');
plot([0.15:0.1:0.75],Density_Vector_mean');
errorbar([0.15:0.1:0.75],Density_Vector_mean',Density_Vector_std','x')
plot(Z_tent_matrix,both3);grid;xlabel('Zp');xlim([0 1]);ylim([0 6]);
plot(Z_tent_matrix,both_filtered,'r');xlabel('z_p');ylabel('Galaxy density within 500 kpc');xlim([0 0.9]);ylim([0 9]);
errorbar(Z_tent_matrix,both_filtered,D_N_zp_500kpc_std_filtered,'rx');
hold off
saveas(gca,'.\OutputResults\Fig6_GalaxyDensity_500kpc','jpeg');

x=1;
end



