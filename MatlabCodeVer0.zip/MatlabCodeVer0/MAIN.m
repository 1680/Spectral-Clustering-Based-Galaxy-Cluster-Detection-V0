%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Eman Mahmoud
%%%  13 June 2016
%%% EJUST


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% M A I N 

clear all
clc
close all

addpath('.\Mfiles/');
% Applying our spectral clustering-based cluster finding algorithm to the
% cluster sample (45) with red shifts
fprintf('Press Enter to apply the algorithm on known clusters (45): \n')
[Density_Vector_mean_500kpc, Density_Vector_std_500kpc, Density_Vector_mean_1arcmin, Density_Vector_std_1arcmin]=MyMainFunction();
pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Galaxy densities 
% Investigating random positions (1arcmin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Press Enter to plot the cluster galaxy densities and random positions within 1arcmin: \n')
pause
x=RandomGalaxyDensity_1arcmin(Density_Vector_mean_1arcmin, Density_Vector_std_1arcmin);
% Investigating random positions (500kpc)
fprintf('Press Enter to plot the cluster galaxy densities and random positions within 500kpc: \n')
pause
x=RandomGalaxyDensity_500kpc(Density_Vector_mean_500kpc, Density_Vector_std_500kpc);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Investigation non optically confirmed clusters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Press Enter to check for new clusters (40 candidates): \n')
pause
x=GalaxyDensitiesTest40(Density_Vector_mean_1arcmin, Density_Vector_std_1arcmin, Density_Vector_mean_500kpc, Density_Vector_std_500kpc);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% E N D

fprintf(' "FinalSampleClusters45.csv" file is created in OutputData folder\n')
fprintf(' "FinalNewClusters.csv" file is created in OutputData folder\n')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

